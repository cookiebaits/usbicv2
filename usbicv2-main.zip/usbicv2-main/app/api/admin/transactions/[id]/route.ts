import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/mongodb";
import Transactionnn from "@/models/Transaction";
import User from "@/models/User";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET is not configured");
}

async function verifyAdminToken(req: NextRequest) {
  console.log("DEBUG: Verifying admin token...");
  const token = req.cookies.get("adminToken")?.value;
  console.log("DEBUG: Token received:", token || "No token");

  if (!token) {
    console.log("DEBUG: No token found, returning 401");
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET as string) as unknown as { adminId: string; role?: string };
    console.log("DEBUG: Token decoded:", decoded);

    if (decoded.role !== "admin") {
      console.log("DEBUG: Role is not admin, returning 403");
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    console.log("DEBUG: Token verification successful");
    return null;
  } catch (error) {
    console.error("DEBUG: Error verifying token:", error);
    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  console.log("DEBUG: Starting POST handler for refund...");
  await dbConnect();

  const authResponse = await verifyAdminToken(req);
  if (authResponse) return authResponse;

  try {
    console.log("DEBUG: Parsing request body...");
    const body = await req.json();
    console.log("DEBUG: Request body:", body);

    const { senderTransactionId, receiverTransactionId } = body;
    console.log("DEBUG: Sender Transaction ID:", senderTransactionId);
    console.log("DEBUG: Receiver Transaction ID:", receiverTransactionId || "Not provided");

    const { id } = await params;
    console.log("DEBUG: URL Param ID:", id);

    if (senderTransactionId !== id) {
      console.log("DEBUG: Sender Transaction ID does not match URL param ID");
      return NextResponse.json({ error: "Sender Transaction ID mismatch" }, { status: 400 });
    }

    const transactionIdsToRefund = [senderTransactionId];
    if (receiverTransactionId) transactionIdsToRefund.push(receiverTransactionId);
    console.log("DEBUG: Transactions to refund:", transactionIdsToRefund);

    const transactions = await Transactionnn.find({ _id: { $in: transactionIdsToRefund } }).populate("userId");
    console.log("DEBUG: Fetched transactions:", JSON.stringify(transactions, null, 2));

    if (transactions.length !== transactionIdsToRefund.length) {
      console.log("DEBUG: Not all transactions found");
      return NextResponse.json({ error: "One or more transactions not found" }, { status: 404 });
    }

    const refundTransactions = [];
    const usersToUpdate = new Map<string, { balanceChange: number; savingsBalanceChange: number; cryptoBalanceChange: number }>();

    for (const originalTransaction of transactions) {
      console.log(`DEBUG: Processing transaction ${originalTransaction._id}...`);

      if (originalTransaction.type === "refund") {
        console.log(`DEBUG: Transaction ${originalTransaction._id} is already a refund`);
        return NextResponse.json({ error: "Cannot refund a refunded transaction" }, { status: 400 });
      }

      const existingRefund = await Transactionnn.findOne({ relatedTransactionId: originalTransaction._id });
      if (existingRefund) {
        console.log(`DEBUG: Transaction ${originalTransaction._id} already refunded`);
        return NextResponse.json({ error: "Transaction already refunded" }, { status: 400 });
      }

      const isTransfer = originalTransaction.category === "Transfer" ? true : false;
      const isCrypto = originalTransaction.type === "crypto_buy" || originalTransaction.type === "crypto_sell" || originalTransaction.type === "bitcoin_transfer";

      const refund = new Transactionnn({
        userId: originalTransaction.userId._id,
        description: `Refund for ${originalTransaction.description}`,
        amount: -originalTransaction.amount,
        date: new Date(),
        type: "refund",
        category: originalTransaction.category,
        accountType: originalTransaction.accountType,
        status: "completed",
        memo: `Refund for transaction ${originalTransaction._id}`,
        relatedTransactionId: originalTransaction._id,
        transferId: originalTransaction.transferId,
        cryptoAmount: isCrypto ? -originalTransaction.cryptoAmount : undefined,
        cryptoPrice: isCrypto ? originalTransaction.cryptoPrice : undefined,
        recipientWallet: originalTransaction.recipientWallet,
      });
      console.log(`DEBUG: Created refund transaction for ${originalTransaction._id}:`, JSON.stringify(refund, null, 2));
      refundTransactions.push(refund);

      const userId = originalTransaction.userId._id.toString();
      const userUpdate = usersToUpdate.get(userId) || { balanceChange: 0, savingsBalanceChange: 0, cryptoBalanceChange: 0 };

      if (isTransfer) {
        if (originalTransaction.accountType === "checking") {
          userUpdate.balanceChange -= originalTransaction.amount;
          userUpdate.savingsBalanceChange += originalTransaction.amount;
        } else if (originalTransaction.accountType === "savings") {
          userUpdate.savingsBalanceChange -= originalTransaction.amount;
          userUpdate.balanceChange += originalTransaction.amount;
        }
      } else if (isCrypto) {
        if (originalTransaction.type === "crypto_buy") {
          userUpdate.balanceChange += -originalTransaction.amount;
          userUpdate.cryptoBalanceChange += -(originalTransaction.cryptoAmount || 0);
        } else if (originalTransaction.type === "crypto_sell") {
          userUpdate.balanceChange += -originalTransaction.amount;
          userUpdate.cryptoBalanceChange += -(originalTransaction.cryptoAmount || 0);
        } else if (originalTransaction.type === "bitcoin_transfer") {
          userUpdate.cryptoBalanceChange += -(originalTransaction.cryptoAmount || 0);
        }
      } else {
        if (originalTransaction.accountType === "checking") {
          userUpdate.balanceChange += -originalTransaction.amount;
        } else if (originalTransaction.accountType === "savings") {
          userUpdate.savingsBalanceChange += -originalTransaction.amount;
        }
      }

      usersToUpdate.set(userId, userUpdate);
      console.log(`DEBUG: Updated user balance for ${userId}:`, userUpdate);
    }

    for (const [userId, { balanceChange, savingsBalanceChange, cryptoBalanceChange }] of usersToUpdate) {
      console.log(`DEBUG: Validating balance for user ${userId}...`);
      if (balanceChange < 0 || savingsBalanceChange < 0 || cryptoBalanceChange < 0) {
        const user = await User.findById(userId);
        console.log(`DEBUG: Fetched user ${userId}:`, user ? JSON.stringify(user, null, 2) : "Not found");
        if (!user) {
          console.log(`DEBUG: User ${userId} not found`);
          return NextResponse.json({ error: `User ${userId} not found` }, { status: 404 });
        }
        const newBalance = (user.balance || 0) + balanceChange;
        const newSavingsBalance = (user.savingsBalance || 0) + savingsBalanceChange;
        const newCryptoBalance = (user.cryptoBalance || 0) + cryptoBalanceChange;
        console.log(`DEBUG: New balance for ${userId}: Checking: ${newBalance}, Savings: ${newSavingsBalance}, Crypto: ${newCryptoBalance}`);
        if (newBalance < 0 || newSavingsBalance < 0 || newCryptoBalance < 0) {
          console.log(`DEBUG: Insufficient balance for user ${userId}`);
          return NextResponse.json({ error: `Insufficient balance for user ${userId}` }, { status: 400 });
        }
      }
    }

    console.log("DEBUG: Updating user balances...");
    for (const [userId, { balanceChange, savingsBalanceChange, cryptoBalanceChange }] of usersToUpdate) {
      const user = await User.findById(userId);
      if (user) {
        user.balance = (user.balance || 0) + balanceChange;
        user.savingsBalance = (user.savingsBalance || 0) + savingsBalanceChange;
        user.cryptoBalance = (user.cryptoBalance || 0) + cryptoBalanceChange;
        await user.save();
        console.log(`DEBUG: Updated user ${userId} - Balance: ${user.balance}, Savings: ${user.savingsBalance}, Crypto: ${user.cryptoBalance}`);
      }
    }

    console.log("DEBUG: Saving refund transactions...");
    await Promise.all(refundTransactions.map((tx) => tx.save()));
    console.log("DEBUG: Refund transactions saved");

    console.log("DEBUG: Refund processing completed successfully");

    const response = {
      message: "Refund processed successfully",
      refundTransactions: refundTransactions.map((tx) => ({
        id: tx._id.toString(),
        userId: tx.userId.toString(),
        userName: tx.userId.fullName || "Unknown",
        userEmail: tx.userId.email || "Unknown",
        type: tx.type,
        amount: tx.amount,
        description: tx.description,
        date: tx.date.toISOString(),
        status: tx.status,
        account: tx.accountType,
        memo: tx.memo,
        relatedTransactionId: tx.relatedTransactionId?.toString(),
        cryptoAmount: tx.cryptoAmount || 0,
        cryptoPrice: tx.cryptoPrice || 0,
        recipientWallet: tx.recipientWallet || "",
      })),
    };
    console.log("DEBUG: Sending response:", JSON.stringify(response, null, 2));

    return NextResponse.json(response);
  } catch (error) {
    console.error("DEBUG: Error processing refund:", error);
    return NextResponse.json({ error: "Failed to process refund" }, { status: 500 });
  }
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  console.log("DEBUG: Starting GET handler...");
  await dbConnect();

  const authResponse = await verifyAdminToken(req);
  if (authResponse) return authResponse;

  try {
    const { id } = await params;
    console.log("DEBUG: Fetching transaction with ID:", id);
    const transaction = await Transactionnn.findById(id).populate("userId", "fullName email");
    console.log("DEBUG: Fetched transaction:", transaction ? JSON.stringify(transaction, null, 2) : "Not found");

    if (!transaction) {
      console.log("DEBUG: Transaction not found, returning 404");
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    const response = {
      transaction: {
        id: transaction._id.toString(),
        userId: transaction.userId._id.toString(),
        userName: transaction.userId.fullName,
        userEmail: transaction.userId.email,
        type: transaction.type,
        category: transaction.category || "Unknown",
        amount: transaction.amount,
        description: transaction.description,
        date: transaction.date.toISOString(),
        status: transaction.status,
        account: transaction.accountType,
        memo: transaction.memo || "",
        relatedTransactionId: transaction.relatedTransactionId?.toString(),
        cryptoAmount: transaction.cryptoAmount || 0,
        cryptoPrice: transaction.cryptoPrice || 0,
        transferId: transaction.transferId || "",
        recipientWallet: transaction.recipientWallet || "",
      },
    };
    console.log("DEBUG: Sending GET response:", JSON.stringify(response, null, 2));

    return NextResponse.json(response);
  } catch (error) {
    console.error("DEBUG: Error fetching transaction:", error);
    return NextResponse.json({ error: "Failed to fetch transaction" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  console.log("DEBUG: Starting PUT handler...");
  await dbConnect();

  const authResponse = await verifyAdminToken(req);
  if (authResponse) return authResponse;

  try {
    const { id } = await params;
    console.log("DEBUG: Updating transaction with ID:", id);
    const body = await req.json();
    console.log("DEBUG: PUT request body:", body);

    const { description, amount, type, category, status, memo, cryptoAmount, cryptoPrice, recipientWallet, date } = body;

    if (!description || isNaN(amount) || !type || !status || !category) {
      console.log("DEBUG: Invalid input data, returning 400");
      return NextResponse.json({ error: "Invalid input data" }, { status: 400 });
    }

    const validTypes = [
      "deposit",
      "withdrawal",
      "transfer",
      "payment",
      "fee",
      "interest",
      "crypto_buy",
      "crypto_sell",
      "bitcoin_transfer",
      "refund",
    ];
    if (!validTypes.includes(type)) {
      console.log("DEBUG: Invalid transaction type:", type);
      return NextResponse.json({ error: "Invalid transaction type" }, { status: 400 });
    }

    const validStatuses = ["completed", "pending", "failed", "refunded"];
    if (!validStatuses.includes(status)) {
      console.log("DEBUG: Invalid transaction status:", status);
      return NextResponse.json({ error: "Invalid transaction status" }, { status: 400 });
    }

    const transaction = await Transactionnn.findById(id);
    console.log("DEBUG: Fetched transaction for update:", transaction ? JSON.stringify(transaction, null, 2) : "Not found");

    if (!transaction) {
      console.log("DEBUG: Transaction not found, returning 404");
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    if (transaction.type === "refund") {
      console.log("DEBUG: Cannot update refund transaction");
      return NextResponse.json({ error: "Cannot update refund transactions" }, { status: 400 });
    }

    const user = await User.findById(transaction.userId);
    console.log("DEBUG: Fetched user for balance update:", user ? JSON.stringify(user, null, 2) : "Not found");
    if (!user) {
      console.log("DEBUG: User not found, returning 404");
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const isCrypto = type === "crypto_buy" || type === "crypto_sell" || type === "bitcoin_transfer";
    const oldAmount = transaction.amount;
    const newAmount = amount;
    const amountDifference = newAmount - oldAmount;

    const oldCryptoAmount = transaction.cryptoAmount || 0;
    const newCryptoAmount = cryptoAmount || 0;
    const cryptoAmountDifference = newCryptoAmount - oldCryptoAmount;

    let balanceChange = 0;
    let savingsBalanceChange = 0;
    let cryptoBalanceChange = 0;

    if (isCrypto) {
      if (type === "crypto_buy") {
        balanceChange = -amountDifference;
        cryptoBalanceChange = cryptoAmountDifference;
      } else if (type === "crypto_sell") {
        balanceChange = amountDifference;
        cryptoBalanceChange = -cryptoAmountDifference;
      } else if (type === "bitcoin_transfer") {
        cryptoBalanceChange = -cryptoAmountDifference;
      }
    } else if (transaction.category === "Transfer") {
      if (transaction.accountType === "checking") {
        balanceChange = amountDifference;
        savingsBalanceChange = -amountDifference;
      } else if (transaction.accountType === "savings") {
        savingsBalanceChange = amountDifference;
        balanceChange = -amountDifference;
      }
    } else {
      if (transaction.accountType === "checking") {
        balanceChange = amountDifference;
      } else if (transaction.accountType === "savings") {
        savingsBalanceChange = amountDifference;
      }
    }

    const newBalance = (user.balance || 0) + balanceChange;
    const newSavingsBalance = (user.savingsBalance || 0) + savingsBalanceChange;
    const newCryptoBalance = (user.cryptoBalance || 0) + cryptoBalanceChange;
    console.log(
      `DEBUG: Balance validation - New Balance: ${newBalance}, New Savings Balance: ${newSavingsBalance}, New Crypto Balance: ${newCryptoBalance}`
    );

    if (newBalance < 0 || newSavingsBalance < 0 || newCryptoBalance < 0) {
      console.log("DEBUG: Insufficient balance for update");
      return NextResponse.json({ error: "Insufficient balance for update" }, { status: 400 });
    }

    user.balance = newBalance;
    user.savingsBalance = newSavingsBalance;
    user.cryptoBalance = newCryptoBalance;
    console.log(
      `DEBUG: Updated user ${user._id} - Balance: ${user.balance}, Savings: ${user.savingsBalance}, Crypto: ${user.cryptoBalance}`
    );
    await user.save();

    transaction.description = description;
    transaction.amount = amount;
    transaction.type = type;
    transaction.category = category;
    transaction.status = status;
    transaction.memo = memo || "";
    transaction.date = new Date(date);
    if (isCrypto) {
      transaction.cryptoAmount = cryptoAmount;
      transaction.cryptoPrice = cryptoPrice || 0;
      transaction.recipientWallet = recipientWallet || "";
    } else {
      transaction.cryptoAmount = undefined;
      transaction.cryptoPrice = undefined;
      transaction.recipientWallet = undefined;
    }
    console.log("DEBUG: Updated transaction:", JSON.stringify(transaction, null, 2));
    await transaction.save();

    if (transaction.type === "transfer" && transaction.category === "Transfer" && transaction.transferId) {
      const other = await Transactionnn.findOne({
        transferId: transaction.transferId,
        _id: { $ne: transaction._id },
      });
      if (other) {
        other.amount = -transaction.amount;
        other.description = transaction.description;
        other.memo = transaction.memo;
        other.date = transaction.date;
        await other.save();
        console.log("DEBUG: Updated paired transfer transaction:", other._id);
      }
    }

    console.log("DEBUG: Transaction update completed successfully");

    const response = {
      transaction: {
        id: transaction._id.toString(),
        userId: transaction.userId.toString(),
        userName: user.fullName,
        userEmail: user.email,
        type: transaction.type,
        category: transaction.category || "Unknown",
        amount: transaction.amount,
        description: transaction.description,
        date: transaction.date.toISOString(),
        status: transaction.status,
        account: transaction.accountType,
        memo: transaction.memo || "",
        relatedTransactionId: transaction.relatedTransactionId?.toString(),
        cryptoAmount: transaction.cryptoAmount || 0,
        cryptoPrice: transaction.cryptoPrice || 0,
        transferId: transaction.transferId || "",
        recipientWallet: transaction.recipientWallet || ""
      },
      user: {
        id: user._id.toString(),
        fullName: user.fullName,
        email: user.email,
        accountNumber: user.accountNumber || "Unknown",
        balance: user.balance,
        savingsBalance: user.savingsBalance,
        cryptoBalance: user.cryptoBalance,
      },
    };
    console.log("DEBUG: Sending PUT response:", JSON.stringify(response, null, 2));

    return NextResponse.json(response);
  } catch (error) {
    console.error("DEBUG: Error updating transaction:", error);
    return NextResponse.json({ error: "Failed to update transaction" }, { status: 500 });
  }
}